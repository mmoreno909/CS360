package com.example.cs36032;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import androidx.appcompat.app.AppCompatActivity;

public class ViewWeightsActivity extends AppCompatActivity {
    private ListView listViewWeights;
    private DatabaseHelper db;
    private long userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_weights);

        listViewWeights = findViewById(R.id.listViewWeights);
        db = new DatabaseHelper(this);

        // Assuming userId is passed via intent
        userId = getIntent().getLongExtra("USER_ID", -1);

        if (userId != -1) {
            loadWeights(userId);
        } else {
            // Handle the case where userId is not available
        }
    }

    private void loadWeights(long userId) {
        Cursor cursor = db.getWeights(userId);

        if (cursor != null && cursor.getCount() > 0) {
            SimpleCursorAdapter adapter = new SimpleCursorAdapter(
                    this,
                    R.layout.weight_item,
                    cursor,
                    new String[]{db.getColumnWeight(), db.getColumnDate()},
                    new int[]{R.id.tvWeight, R.id.tvDate},
                    0
            );
            listViewWeights.setAdapter(adapter);
        } else {
            // Handle the case where there are no weights to display
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Close the database connection when the activity is destroyed
        db.close();
    }
}