package com.example.cs36032;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class AddWeightActivity extends AppCompatActivity {
    private EditText etWeight;
    private Button btnSave;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        etWeight = findViewById(R.id.etWeight);
        btnSave = findViewById(R.id.btnSave);
        db = new DatabaseHelper(this);

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    double weight = Double.parseDouble(etWeight.getText().toString().trim());
                    // For now, hardcode user ID or retrieve it from intent/session
                    long userId = 1; // Replace with actual user ID retrieval method
                    String date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

                    if (db.addWeight(userId, weight, date)) {
                        Toast.makeText(AddWeightActivity.this, "Weight recorded successfully", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(AddWeightActivity.this, "Failed to record weight", Toast.LENGTH_SHORT).show();
                    }
                } catch (NumberFormatException e) {
                    Toast.makeText(AddWeightActivity.this, "Invalid weight input", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}