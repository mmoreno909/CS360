package com.example.cs36032;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class WeightAdapter extends RecyclerView.Adapter<WeightAdapter.ViewHolder> {
    private final List<Weight> weightList;

    public WeightAdapter(List<Weight> weightList) {
        this.weightList = weightList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weight_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Weight weight = weightList.get(position);
        holder.tvWeight.setText("Weight: " + weight.getWeight() + " kg");
        holder.tvDate.setText("Date: " + weight.getDate());
    }

    @Override
    public int getItemCount() {
        return weightList.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvWeight;
        TextView tvDate;

        ViewHolder(View itemView) {
            super(itemView);
            tvWeight = itemView.findViewById(R.id.tvWeight);
            tvDate = itemView.findViewById(R.id.tvDate);
        }
    }
}